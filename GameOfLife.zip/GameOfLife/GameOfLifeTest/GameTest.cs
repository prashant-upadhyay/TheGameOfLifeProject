﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using GameOfLife;

namespace GameOfLifeTest
{
    [TestClass]
    public class GameTest
    {
        /// <summary>
        ///A test for GameOfLifeGrid Constructor
        ///</summary>
        [TestMethod()]
        public void GameConstructorPositiveTest()
        {
            int[,] matrix = new int[,]
	        {
		        { 1, 0, 0, 0, 0, 0, 0, 0, 1, 1,},
		        { 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,},
		        { 0, 1, 1, 0, 1, 1, 1, 0, 0, 0,},
		        { 0, 1, 0, 0, 0, 1, 0, 0, 0, 0,},
		        { 0, 0, 0, 0, 0, 0, 0, 1, 0, 1,},
		        { 0, 0, 0, 0, 1, 0, 0, 0, 1, 1,},
		        { 0, 1, 0, 0, 1, 0, 0, 1, 0, 0,},
		        { 1, 1, 0, 0, 1, 0, 0, 0, 0, 0,},
	        };
            GameOfLifeGrid target = new GameOfLifeGrid(matrix);
        }

        /// <summary>
        ///A test for GameOfLifeGrid Constructor
        ///</summary>
        [TestMethod()]
        [ExpectedException(typeof(NullReferenceException), "Row and Column size must be greater than or equal to zero")]
        public void GridConstructorExceptionTest1()
        {
            int[,] matrix = null;
            GameOfLifeGrid target = new GameOfLifeGrid(matrix);
        }

     }
}
