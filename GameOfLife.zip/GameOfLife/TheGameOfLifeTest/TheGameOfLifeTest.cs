﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TheGameOfLifeTest
{
    [TestClass]
    public class TheGameOfLifeTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
