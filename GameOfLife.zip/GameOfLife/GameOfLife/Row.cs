﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameOfLife
{
    public class Row
    {
        //list of cells
        public List<LifeCell> Cells { get; set; }

        /// <summary>
        /// initialize list of cells
        /// </summary>
        public Row()
        {
            Cells = new List<LifeCell>();
        }
        /// <summary    >
        /// Add a cell into the row
        /// </summary>
        /// <param name="cell"></param>
        public void AddCell(LifeCell cell)
        {
            Cells.Add(cell);
        }
        /// <summary>
        /// Insert a cell into specified index position
        /// </summary>
        /// <param name="index"></param>
        /// <param name="cell"></param>
        /// <param name="ColumnCount"></param>
        public void InsertCell(int index, LifeCell cell, int ColumnCount)
        {
            Cells.Insert(index, cell);
        }

    }
}
