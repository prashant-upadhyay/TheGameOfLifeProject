﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameOfLife
{
    public class LifeCell
    {
        public Boolean IsLive { get; set; }

        public LifeCell(Boolean islive)
        {
            this.IsLive = islive;
        }
        /// <summary>
        /// ToString implementation of cell
        /// </summary>
        /// <returns>retuns string representation of cell</returns>
        public override string ToString()
        {
            return (IsLive ? " 1 " : " 0 ");
        }
    }
}
