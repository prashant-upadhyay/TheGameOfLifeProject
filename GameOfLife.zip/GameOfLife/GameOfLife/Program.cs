﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameOfLife
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare an input matrix to start the game of life
            int[,] matrix = new int[,]
	        {
		        { 1, 0, 0, 0, 0, 0, 0, 0, 1, 1,},
		        { 0, 0, 1, 0, 0, 1, 0, 0, 0, 0,},
		        { 0, 1, 1, 0, 1, 1, 1, 0, 0, 0,},
		        { 0, 1, 0, 0, 0, 1, 0, 0, 0, 0,},
		        { 0, 0, 0, 0, 0, 0, 0, 1, 0, 1,},
		        { 0, 0, 0, 0, 1, 0, 0, 0, 1, 1,},
		        { 0, 1, 0, 0, 1, 0, 0, 1, 0, 0,},
		        { 1, 1, 0, 0, 1, 0, 0, 0, 0, 0,},
	        };

            //created an object of the GameOfLifeGrid class
            GameOfLifeGrid objGameOfLifeGrid = new GameOfLifeGrid(matrix);

            Console.WriteLine("Generation 0");
            //print the generation sequence for generation 0
            objGameOfLifeGrid.PrintSequence();
            Console.WriteLine();

            while (objGameOfLifeGrid.FactorLiveCells() > 0)
            {
                string response;

                Console.WriteLine();
                Console.WriteLine("Generation {0}", objGameOfLifeGrid.SequenceCount);

                objGameOfLifeGrid.CalculateGeneration();
                objGameOfLifeGrid.PrintSequence();

                Console.WriteLine();

                //display message to user when there are no cells alive else continue
                if (objGameOfLifeGrid.FactorLiveCells() == 0)
                {
                    Console.WriteLine("None of the cells are active now. The game cannot be played further.");
                    Console.ReadLine();
                }
                else
                {
                    Console.WriteLine("Press any key to contiune or Q to quit.");
                    response = Console.ReadLine();
                    if (response == "q" || response == "Q")
                        break;
                }
            }
        }
    }
}
