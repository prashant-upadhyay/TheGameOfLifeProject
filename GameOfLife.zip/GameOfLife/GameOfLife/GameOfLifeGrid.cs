﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace GameOfLife
{
    public class GameOfLifeGrid
    {
        //data members
        //this persists the state of the current matrix
        int[,] currentMatrix;
        //this persists the state of the previous matrix 
        int[,] previousMatrix;
        //counter to persist the number of cycles of iterations
        int sequenceCount;

        //this represents the width and height of the matrix
        int width;
        int height;

        // List of Rows in Grid        
        public List<Row> objMatrix { set; get; }

        //class property to allow the user to get the current matrix generation
        public int SequenceCount
        {
            get { return sequenceCount; }
        }

        /// <summary>
        /// Class constructor
        /// </summary>
        public GameOfLifeGrid(int[,] newGrid)
        {
            //backed up the original matrix, created a clone  of it and retained it into another matrix
            currentMatrix = (int[,])newGrid.Clone();
            //defaulted the sequence count to 1
            sequenceCount = 1;

            width = currentMatrix.GetLength(1);
            height = currentMatrix.GetLength(0);

            previousMatrix = new int[height, width];
        }

        /// <summary>
        /// Count the number of neighbours of the cell[x,y].
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param> 
        private int CountNeighbours(int x, int y)
        {
            int count = 0;

            //x - 1, y - 1
            if (x > 0 && y > 0)
            {
                if (currentMatrix[y - 1, x - 1] == 1)
                    count++;
            }
            //x, y - 1
            if (y > 0)
            {
                if (currentMatrix[y - 1, x] == 1)
                    count++;
            }
            // x + 1, y - 1
            if (x < width - 1 && y > 0)
            {
                if (currentMatrix[y - 1, x + 1] == 1)
                    count++;
            }
            //x - 1, y
            if (x > 0)
            {
                if (currentMatrix[y, x - 1] == 1)
                    count++;
            }
            //x + 1, y
            if (x < width - 1)
            {
                if (currentMatrix[y, x + 1] == 1)
                    count++;
            }
            //x - 1, y + 1
            if (x > 0 && y < height - 1)
            {
                if (currentMatrix[y + 1, x - 1] == 1)
                    count++;
            }
            //x, y + 1
            if (y < height - 1)
            {
                if (currentMatrix[y + 1, x] == 1)
                    count++;
            }
            //x + 1, y + 1
            if (x < width - 1 && y < height - 1)
            {
                if (currentMatrix[y + 1, x + 1] == 1)
                    count++;
            }
            return count;
        }

        /// <summary>
        /// iterate over each cell and display the number of neighbours the cell has.
        /// </summary>
        public void LocateNeighbours()
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                    Console.Write("{0}", CountNeighbours(x, y));
                Console.WriteLine();
            }
        }

        /// <summary>
        /// iterate over each cell and calculate the generation.
        /// </summary>
        public void CalculateGeneration()
        {
            //created a local variable to persist the next state
            int[,] nextGeneration = new int[height, width];

            //cloned the current matrix and assign it to previous one.
            //used clone() to preserve the original content and avoid overriding of the current state.
            previousMatrix = (int[,])currentMatrix.Clone();

            sequenceCount++;

            //iterate each cell in the matrix
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    if (currentMatrix[y, x] == 0 && CountNeighbours(x, y) == 3)
                        nextGeneration[y, x] = 1;
                    if (currentMatrix[y, x] == 1 && (CountNeighbours(x, y) == 2 || CountNeighbours(x, y) == 3))
                        nextGeneration[y, x] = 1;
                }
            }
            currentMatrix = (int[,])nextGeneration.Clone();
        }

        /// <summary>
        /// print the sequence of the generations
        /// </summary>
        public void PrintSequence()
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                    Console.Write("{0}", currentMatrix[y, x]);
                Console.WriteLine();
            }
            Console.WriteLine();
        }

        /// <summary>
        /// count the number of live cells
        /// </summary>
        public int FactorLiveCells()
        {
            int count = 0;
            for (int y = 0; y < height; y++)
                for (int x = 0; x < width; x++)
                    if (currentMatrix[y, x] == 1)
                        count++;
            return count;
        }
    }
}



